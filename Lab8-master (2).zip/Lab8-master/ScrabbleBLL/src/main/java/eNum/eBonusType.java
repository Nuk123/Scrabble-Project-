package eNum;

public enum eBonusType {
	TripleWord, DoubleWord, TripleLetter, DoubleLetter, Star;
}
