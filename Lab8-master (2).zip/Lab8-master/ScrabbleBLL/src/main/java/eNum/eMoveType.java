package eNum;

public enum eMoveType {

	HORIZONTAL, VERTICAL;
}
