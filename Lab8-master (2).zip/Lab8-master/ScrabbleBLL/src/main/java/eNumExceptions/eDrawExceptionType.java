package eNumExceptions;

public enum eDrawExceptionType {

	TileBagEmpty;
}
