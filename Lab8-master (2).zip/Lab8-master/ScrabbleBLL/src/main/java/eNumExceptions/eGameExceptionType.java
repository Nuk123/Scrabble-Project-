package eNumExceptions;

public enum eGameExceptionType {

	NoPlayers;
}
