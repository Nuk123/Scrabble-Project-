package pkgHelper;

public class Util {

	public static void PrintStart(String strMethodName)
	{
		System.out.println("---" + strMethodName + " Start---");
	}
	public static void PrintEnd(String strMethodName)
	{
		System.out.println("---" + strMethodName + " Complete---");
	}

}
